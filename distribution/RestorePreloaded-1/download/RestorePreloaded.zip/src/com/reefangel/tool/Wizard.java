/**
 * you can put a one sentence description of your tool here.
 *
 * (C) 2012
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author		Reef Angel http://www.reefangel.com
 * @modified	04/09/2012
 * @version		##version##
 */

 package com.reefangel.tool;
 
 import processing.app.*;
 import processing.app.tools.*;
 import processing.app.Base.*;
 import processing.app.Editor;
 import processing.app.tools.Tool;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.SplashScreen;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
  
 public class Wizard implements Tool {
	 Editor editor;
 
	 private static final String A_HREF = "<a href=\""; 
	 private static final String HREF_CLOSED = "\">"; 
	 private static final String HREF_END = "</a>"; 
	 private static final String HTML = "<html>"; 
	 private static final String HTML_END = "</html>"; 

	public String getMenuTitle() {
		return "Restore Preloaded Code";
	}
 
	public void init(Editor theEditor) {
		this.editor = theEditor;
	}
 
	public void run() {
    	if (editor.getSketch().getCode(0).isModified())
    	{
    		JOptionPane.showMessageDialog(editor,
                    "You must save the currect sketch before proceeding",
                    "Error",JOptionPane.ERROR_MESSAGE);
    		return;
    	}

		editor.getBase();
		
		ShowStep1();
	
		ShowStep2();

		//	    	System.out.println(editor.getSketch().getPrimaryFile());
    }

	
	private void ShowStep1()
	{
    	JPanel panel = new JPanel();

    	JPanel panel1 = new JPanel();
    	JPanel panel2 = new JPanel();
    	
    	panel1.setLayout(new BoxLayout( panel1, BoxLayout.PAGE_AXIS));
    	panel2.setLayout(new BoxLayout( panel2, BoxLayout.PAGE_AXIS));
    	
    	ImageIcon icon=null;
		try {
			icon = new ImageIcon(new URL("http://reefangel.com/images/restore_preloaded/ra_small.png"));
	    	} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		panel1.add(new JLabel(icon));
    	JLabel RA_link = new JLabel("http://www.reefangel.com"); 
	    if (isBrowsingSupported()) { 
	        makeLinkable(RA_link, new LinkMouseListener()); 
	    } 
	    panel1.add(RA_link);

		JLabel steps = new JLabel("Welcome to the Reef Angel Wizard");
    	steps.setForeground(new Color(58,95,205));
    	steps.setFont(new Font("Arial", Font.BOLD, 24));
    	panel2.add(steps);

    	JLabel text = new JLabel("<HTML><br>I'm going to walk you through generating the code for your Reef Angel Controller<br><br></HTML>");
    	panel2.add(text);

    	panel.add(panel1);
    	panel.add(panel2);
		JOptionPane.showMessageDialog(editor,
    			panel,
                "Step 1",JOptionPane.DEFAULT_OPTION);		
	}

	private void ShowStep2()
	{
    	JPanel panel = new JPanel();

    	JPanel panel1 = new JPanel();
    	JPanel panel2 = new JPanel();
    	
    	panel1.setLayout(new BoxLayout( panel1, BoxLayout.PAGE_AXIS));
    	panel2.setLayout(new BoxLayout( panel2, BoxLayout.PAGE_AXIS));
    	
    	ImageIcon icon=null;
		try {
			icon = new ImageIcon(new URL("http://reefangel.com/images/restore_preloaded/ra_small.png"));
	    	} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		panel1.add(new JLabel(icon));
    	JLabel RA_link = new JLabel("http://www.reefangel.com"); 
	    if (isBrowsingSupported()) { 
	        makeLinkable(RA_link, new LinkMouseListener()); 
	    } 
	    panel1.add(RA_link);

		JLabel steps = new JLabel("Step 2");
    	steps.setForeground(new Color(58,95,205));
    	steps.setFont(new Font("Arial", Font.BOLD, 24));
    	panel2.add(steps);

    	JLabel text = new JLabel("<HTML><br>Arduino is now compiling your sketch.<br>In a few seconds, it will start uploading the code to your Reef Angel Controller.<br>When the upload process completes, your Reef Angel Controller will have<br>the same pre-loaded code that was originally shipped with your controller.<br><br></HTML>");
    	panel2.add(text);

    	panel.add(panel1);
    	panel.add(panel2);
		JOptionPane.showMessageDialog(editor,
    			panel,
                "Step 2",JOptionPane.DEFAULT_OPTION);		
	}
	
	private static void makeLinkable(JLabel c, MouseListener ml) { 
	    assert ml != null; 
	    c.setText(htmlIfy(linkIfy(c.getText()))); 
	    c.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR)); 
	    c.addMouseListener(ml); 
	} 
	
	private static boolean isBrowsingSupported() { 
	    if (!Desktop.isDesktopSupported()) { 
	        return false; 
	    } 
	    boolean result = false; 
	    Desktop desktop = java.awt.Desktop.getDesktop(); 
	    if (desktop.isSupported(Desktop.Action.BROWSE)) { 
	        result = true; 
	    } 
	    return result; 
	 
	} 

	private static class LinkMouseListener extends MouseAdapter { 
		 
	    @Override 
	    public void mouseClicked(java.awt.event.MouseEvent evt) { 
	        JLabel l = (JLabel) evt.getSource(); 
	        try { 
	            Desktop desktop = java.awt.Desktop.getDesktop(); 
	            URI uri = new java.net.URI(getPlainLink(l.getText())); 
	            desktop.browse(uri); 
	        } catch (URISyntaxException use) { 
	            throw new AssertionError(use); 
	        } catch (IOException ioe) { 
	            ioe.printStackTrace(); 
	            JOptionPane.showMessageDialog(null, "Sorry, a problem occurred while trying to open this link in your system's standard browser.", "A problem occured", JOptionPane.ERROR_MESSAGE); 
	        } 
	    } 
	} 
	 
	private static String getPlainLink(String s) { 
	    return s.substring(s.indexOf(A_HREF) + A_HREF.length(), s.indexOf(HREF_CLOSED)); 
	} 

	private static String linkIfy(String s) { 
	    return A_HREF.concat(s).concat(HREF_CLOSED).concat(s).concat(HREF_END); 
	} 

	private static String htmlIfy(String s) { 
	    return HTML.concat(s).concat(HTML_END); 
	} 
	
	  public static void copy(String fromFileName, String toFileName)
		      throws IOException {
		    File fromFile = new File(fromFileName);
		    File toFile = new File(toFileName);

		    if (!fromFile.exists())
		      throw new IOException("FileCopy: " + "no such source file: "
		          + fromFileName);
		    if (!fromFile.isFile())
		      throw new IOException("FileCopy: " + "can't copy directory: "
		          + fromFileName);
		    if (!fromFile.canRead())
		      throw new IOException("FileCopy: " + "source file is unreadable: "
		          + fromFileName);

		    if (toFile.isDirectory())
		      toFile = new File(toFile, fromFile.getName());

		    if (toFile.exists()) {
		    	toFile.delete();
//		      if (!toFile.canWrite())
//		        throw new IOException("FileCopy: "
//		            + "destination file is unwriteable: " + toFileName);
//		      System.out.print("Overwrite existing file " + toFile.getName()
//		          + "? (Y/N): ");
//		      System.out.flush();
//		      BufferedReader in = new BufferedReader(new InputStreamReader(
//		          System.in));
//		      String response = in.readLine();
//		      if (!response.equals("Y") && !response.equals("y"))
//		        throw new IOException("FileCopy: "
//		            + "existing file was not overwritten.");
		    } else {
		      String parent = toFile.getParent();
		      if (parent == null)
		        parent = System.getProperty("user.dir");
		      File dir = new File(parent);
		      if (!dir.exists())
		        throw new IOException("FileCopy: "
		            + "destination directory doesn't exist: " + parent);
		      if (dir.isFile())
		        throw new IOException("FileCopy: "
		            + "destination is not a directory: " + parent);
		      if (!dir.canWrite())
		        throw new IOException("FileCopy: "
		            + "destination directory is unwriteable: " + parent);
		    }

		    FileInputStream from = null;
		    FileOutputStream to = null;
		    try {
		      from = new FileInputStream(fromFile);
		      to = new FileOutputStream(toFile);
		      byte[] buffer = new byte[4096];
		      int bytesRead;

		      while ((bytesRead = from.read(buffer)) != -1)
		        to.write(buffer, 0, bytesRead); // write
		    } finally {
		      if (from != null)
		        try {
		          from.close();
		        } catch (IOException e) {
		          ;
		        }
		      if (to != null)
		        try {
		          to.close();
		        } catch (IOException e) {
		          ;
		        }
		    }
		  }


	}
 
 



